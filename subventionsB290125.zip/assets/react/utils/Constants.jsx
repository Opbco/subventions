const CONSTANTS = {
  BASE_API_URL: "http://local.services.minesec.gov.cm/api/v1",
  BASE_URL: "http://local.services.minesec.gov.cm",
  REACT_APP_SITE_KEY: "6LdJWoopAAAAACTj0-C_BtkVIdWLc9nLenEXJII7",
  REACT_APP_SECRET_KEY: "6LdJWoopAAAAAIz_QtksOaDsqLZff3BRaULeFpeX"
};

export default CONSTANTS;